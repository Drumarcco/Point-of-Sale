﻿module.exports = {
  "name": "html",
  "main": "lib/html.js",
  "hasPublicPart": false
}