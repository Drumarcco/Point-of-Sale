﻿module.exports = {
  "name": "html-to-xlsx",
  "main": "lib/htmlToXlsx.js",
  "dependencies": ["xlsx"],
  "hasPublicPart": false
}