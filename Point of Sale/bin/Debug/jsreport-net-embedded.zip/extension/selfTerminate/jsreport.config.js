﻿module.exports = {
  "name": "selfTerminate",
  "main": "lib/selfTerminate.js", 
  "hasPublicPart": false
}