﻿module.exports = {
  "name": "public-templates",
  "dependencies": [ "templates" ],
  "main": "lib/main.js",
  "embeddedSupport":true
}