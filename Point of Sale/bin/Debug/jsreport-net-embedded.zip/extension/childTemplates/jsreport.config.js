﻿module.exports = {
  "name": "childTemplates",
  "main": "lib/childTemplates.js",
  "dependencies": [ "templates" ],
  "hasPublicPart": false
}