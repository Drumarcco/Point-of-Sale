﻿module.exports = {
  "name": "authorization",
  "main": "lib/authorization.js",

  "dependencies": [ "authentication" ]
}