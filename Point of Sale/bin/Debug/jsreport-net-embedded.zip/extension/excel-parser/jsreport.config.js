﻿module.exports = {
  "name": "excel-parser",
  "main": "lib/excelParser.js",
  "dependencies": [ "templates" ],
  "hasPublicPart": false
}