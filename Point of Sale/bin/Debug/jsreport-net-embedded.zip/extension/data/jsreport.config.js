﻿module.exports = {
  "name": "data",
  "main": "lib/data.js",
  "dependencies": ["templates"],
  "embeddedSupport":true
}