﻿module.exports = {
  "name": "phantom-pdf",
  "main": "lib/phantom.js",
  "dependencies": [ "templates" ],
  "embeddedSupport":true
}